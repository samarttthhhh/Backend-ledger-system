require('dotenv').config();
const nodemailer = require('nodemailer');


const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    type: 'OAuth2',
    user: process.env.EMAIL_USER,
    clientId: process.env.CLIENT_ID,
    clientSecret: process.env.CLIENT_SECRET,
    refreshToken: process.env.REFRESH_TOKEN,
  },
});

// Verify the connection configuration
transporter.verify((error, success) => {
  if (error) {
    console.error('Error connecting to email server:', error);
  } else {
    console.log('Email server is ready to send messages');
  }
});

// Function to send email
const sendEmail = async (to, subject, text, html) => {
  try {
    const info = await transporter.sendMail({
      from: `"Samarth Soni " <${process.env.EMAIL_USER}>`, // sender address
      to, // list of receivers
      subject, // Subject line
      text, // plain text body
      html, // html body
    });

    console.log('Message sent: %s', info.messageId);
    console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));
  } catch (error) {
    console.error('Error sending email:', error);
    throw error;
  }

  console.log("Sending email to:", to)
};

async function sendRegistrationEmail (userEmail, name){
    const subject = "Welcome to Samarth's Ledger App!";
    const text = `Hi ${name}, welcome to Samarth's Ledger App! \n We're excited to have you on board`; 
    const html = `<p>Hi ${name},</p><p>Welcome to Samarth's Ledger App! We're excited to have you on board.</p> \n <p>Best regards,<br/>Samarth Soni</p>`;

    await sendEmail(userEmail, subject, text, html);

    console.log("sendRegistrationEmail called")
}

async function sendTransactionEmail (userEmail, name, amount, toAccount){
    const subject = "Transaction Alert from Samarth's Ledger App";
    const text = `Hi ${name}, a transaction of amount ${amount} has been made to account ${toAccount}. \n Thank you for using Samarth's Ledger App!`; 
    const html = `<p>Hi ${name},</p><p>A transaction of amount <strong>${amount}</strong> has been made to account <strong>${toAccount}</strong>.</p> \n <p>Thank you for using Samarth's Ledger App!</p> \n <p>Best regards,<br/>Samarth Soni</p>`;
    await sendEmail(userEmail, subject, text, html);

}

async function sendTransactionFailureEmail (userEmail, name, amount, toAccount){
    const subject = "Transaction Failure Alert from Samarth's Ledger App";
    const text = `Hi ${name}, a transaction of amount ${amount} to account ${toAccount} has failed. \n Please check your account and try again. Thank you for using Samarth's Ledger App!`; 
    const html = `<p>Hi ${name},</p><p>A transaction of amount <strong>${amount}</strong> to account <strong>${toAccount}</strong> has failed.</p> \n <p>Please check your account and try again.</p> \n <p>Thank you for using Samarth's Ledger App!</p> \n <p>Best regards,<br/>Samarth Soni</p>`;

    await sendEmail(userEmail, subject, text, html);
    
}


module.exports = {
    sendRegistrationEmail,
    sendTransactionEmail,
    sendTransactionFailureEmail
}
