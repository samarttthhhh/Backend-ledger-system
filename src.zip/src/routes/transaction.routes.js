const {Router} = require ("express");
const authMiddleware = require("../middleware/auth.middleware");
const transactionController = require("../controller/transaction.controler")


const transactionRoutes = Router();


transactionRoutes.post("/", authMiddleware.authMiddleware, transactionController.createTransaction)

/** 
 *— POST /api/transactions/system/initial—funds
* — Create initial funds transaction from system user
*/
transactionRoutes.post("/system/initial-funds", authMiddleware.authSystemUserMiddleware, transactionController.createInitialFundsTransaction);

module.exports = transactionRoutes;