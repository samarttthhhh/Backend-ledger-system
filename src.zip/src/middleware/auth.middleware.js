const userModdel = require('../models/users.models')
const jwt = require("jsonwebtoken") 




async function authMiddleware(req, res, next) {
    const token = req.cookies.token || req.headers.authorization?.split(" ")[1]

    if (!token) {
        return res.status(401).json({
            message: "Unauthorized, token missing",
            status: "error"
        })
    }

    try {

        const decoded = jwt.verify(token, process.env.JWT_SECRET)

        const user = await userModdel.findById(decoded.userId)

        req.user = user

        return next()

    } catch (err) {
        return res.status(401).json({
            message: "Unauthorized, invalid token",
            status: "error"
        })
    }
}

async function authSystemUserMiddleware (req, res, next) {

    const token = req.cookies.token || req.headers.authorization?.split(" ")[1]

    if (!token) {
        return res.status(401).json({
            message: "Unauthorized, token missing",
            status: "error"
        })
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET)

        const user = await userModdel.findById(decoded.userId).select("+systemUser")
        if (!user.systemUser) {
            return res.status(403).json({ 
                message: "Forbidden, user is not a system user",
                status: "error"
            })
        }
        req.user = user
        return next()
    }

    catch (err) {
        return res.status(401).json({
            message: "Unauthorized, invalid token",
            status: "error"
        })
    }

}

module.exports = {
    authMiddleware,
    authSystemUserMiddleware
}