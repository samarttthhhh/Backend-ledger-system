const userModel = require("../models/users.models")
const jwt = require("jsonwebtoken")
const emailService = require("../services/email.service")

 async function userRegisterController(req, res) {

    const { email, name, password } = req.body

    const isExist = await userModel.findOne({ email : email})

    if (isExist) {
        return res.status(422).json({
            message: "User already exists",
            status: "error"
        })
    }

    const user = await userModel.create({
        email, name, password
    })

    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, {expiresIn: "3d"})

    res.cookie("token", token)

    res.status(201).json({
        user: {
            email: user.email,
            name: user.name,
            _id: user._id
        },
        token
    }) 

    await emailService.sendRegistrationEmail(user.email, user.name)


}


async function userLoginController(req, res) {
    const { email, password } = req.body
    const user = await userModel.findOne({ email }).select("+password")

    if (!user) {
        return res.status(401).json({
            message: "User not found",
            status: "error"
        })
    }

    const isValidPassword = await user.comparePassword(password)
    if (!isValidPassword) {
        return res.status(401).json({
            message: "Invalid password",
            status: "error"
        })
    }

    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, {expiresIn: "3d"})

    res.cookie("token", token)

    res.status(200).json({
        user: {
            email: user.email,
            name: user.name,
            _id: user._id
        },
        token
    })


}


module.exports = {
    userRegisterController,
    userLoginController

}